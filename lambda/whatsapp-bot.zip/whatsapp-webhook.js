const { LambdaClient, InvokeCommand } = require('@aws-sdk/client-lambda');
const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, QueryCommand } = require('@aws-sdk/lib-dynamodb');

const lambdaClient = new LambdaClient({ region: 'us-east-2' });
const ddbClient = new DynamoDBClient({ region: 'us-east-2' });
const docClient = DynamoDBDocumentClient.from(ddbClient);
const VERIFY_TOKEN = process.env.VERIFY_TOKEN || 'finanzas-verify-token';

exports.handler = async (event) => {
  console.log('Event:', JSON.stringify(event, null, 2));

  // Webhook verification
  if (event.httpMethod === 'GET') {
    const mode = event.queryStringParameters?.['hub.mode'];
    const token = event.queryStringParameters?.['hub.verify_token'];
    const challenge = event.queryStringParameters?.['hub.challenge'];

    if (mode === 'subscribe' && token === VERIFY_TOKEN) {
      return {
        statusCode: 200,
        body: challenge
      };
    }
    return { statusCode: 403, body: 'Forbidden' };
  }

  // Process incoming messages
  if (event.httpMethod === 'POST') {
    try {
      const body = JSON.parse(event.body);
      
      console.log('Body:', JSON.stringify(body, null, 2));
      
      if (body.object === 'whatsapp_business_account') {
        for (const entry of body.entry || []) {
          for (const change of entry.changes || []) {
            console.log('Change:', JSON.stringify(change, null, 2));
            if (change.value?.messages) {
              for (const message of change.value.messages) {
                console.log('Processing message:', message);
                await processMessage(message, change.value.metadata);
              }
            }
          }
        }
      }

      return { statusCode: 200, body: 'OK' };
    } catch (error) {
      console.error('Error:', error);
      return { statusCode: 500, body: JSON.stringify({ error: error.message }) };
    }
  }

  return { statusCode: 405, body: 'Method not allowed' };
};

async function processMessage(message, metadata) {
  const { from, text } = message;
  const messageText = text?.body || '';

  const userId = await getUserByWhatsApp(from);
  if (!userId) {
    console.log('User not found for WhatsApp:', from);
    await sendWhatsAppMessage(from, '❌ Usuario no registrado. Vincula tu WhatsApp desde la app web.');
    return;
  }

  const parsed = parseMessage(messageText);
  
  if (!parsed) {
    console.log('Message not recognized:', messageText);
    await sendWhatsAppMessage(from, '❓ No entendí tu mensaje. Ejemplos:\n• Gasté 25000 en almuerzo\n• Recibí 1000000 de salario\n• Reporte');
    return;
  }

  if (parsed.type === 'transaction') {
    await createTransaction(userId, parsed.data);
    const emoji = parsed.data.transactionType === 'expense' ? '💸' : '💰';
    const type = parsed.data.transactionType === 'expense' ? 'Gasto' : 'Ingreso';
    await sendWhatsAppMessage(from, `${emoji} ${type} registrado:\n$${parsed.data.amount.toLocaleString()} - ${parsed.data.category}`);
  } else if (parsed.type === 'budget') {
    await createBudget(userId, parsed.data);
    await sendWhatsAppMessage(from, `🎯 Presupuesto creado:\n$${parsed.data.amount.toLocaleString()} para ${parsed.data.category}`);
  } else if (parsed.type === 'report') {
    await generateReport(userId);
    await sendWhatsAppMessage(from, '📊 Generando reporte...');
  }
}

async function getUserByWhatsApp(whatsappNumber) {
  const result = await docClient.send(new QueryCommand({
    TableName: 'finanzas-users',
    IndexName: 'whatsapp-index',
    KeyConditionExpression: 'whatsappNumber = :phone',
    ExpressionAttributeValues: {
      ':phone': whatsappNumber
    }
  }));

  return result.Items?.[0]?.userId;
}

function parseMessage(text) {
  const lower = text.toLowerCase();

  // Transaction patterns
  const expenseMatch = lower.match(/(?:gast[eé]|pagu[eé]|compr[eé])\s*\$?(\d+(?:\.\d+)?)\s+(?:en|de|para|por)\s+(.+)/i);
  if (expenseMatch) {
    return {
      type: 'transaction',
      data: {
        amount: parseFloat(expenseMatch[1]),
        description: expenseMatch[2].trim(),
        category: categorize(expenseMatch[2]),
        transactionType: 'expense'
      }
    };
  }

  const incomeMatch = lower.match(/(?:recib[ií]|ingres[oó]|cobr[eé])\s*\$?(\d+(?:\.\d+)?)\s+(?:de|por)?\s*(.+)/i);
  if (incomeMatch) {
    return {
      type: 'transaction',
      data: {
        amount: parseFloat(incomeMatch[1]),
        description: incomeMatch[2].trim(),
        category: 'Ingreso',
        transactionType: 'income'
      }
    };
  }

  // Budget patterns
  const budgetMatch = lower.match(/(?:presupuesto|budget)\s+(?:de\s+)?\$?(\d+(?:\.\d+)?)\s+(?:para|en)\s+(.+)/i);
  if (budgetMatch) {
    return {
      type: 'budget',
      data: {
        amount: parseFloat(budgetMatch[1]),
        category: budgetMatch[2].trim(),
        period: 'month'
      }
    };
  }

  // Report patterns
  if (lower.match(/(?:reporte|resumen|balance|saldo|gastos)/)) {
    return { type: 'report' };
  }

  return null;
}

function categorize(description) {
  const desc = description.toLowerCase();
  const categories = {
    'Alimentación': ['comida', 'almuerzo', 'cena', 'desayuno', 'restaurante', 'mercado', 'supermercado', 'pizza', 'hamburguesa', 'pollo', 'arroz', 'frutas', 'verduras', 'pan', 'café', 'bebida'],
    'Transporte': ['taxi', 'uber', 'gasolina', 'bus', 'metro', 'transporte', 'pasaje', 'combustible', 'parqueadero', 'peaje'],
    'Entretenimiento': ['cine', 'netflix', 'spotify', 'bar', 'fiesta', 'concierto', 'juego', 'videojuego', 'streaming'],
    'Salud': ['farmacia', 'medicina', 'doctor', 'hospital', 'consulta', 'medicamento', 'droga', 'vitamina'],
    'Educación': ['libro', 'curso', 'universidad', 'colegio', 'matrícula', 'estudio', 'clase'],
    'Servicios': ['luz', 'agua', 'internet', 'teléfono', 'cable', 'arriendo', 'alquiler', 'gas']
  };

  for (const [cat, keywords] of Object.entries(categories)) {
    if (keywords.some(k => desc.includes(k))) return cat;
  }
  return 'Otros';
}

async function createTransaction(userId, data) {
  const payload = {
    httpMethod: 'POST',
    body: JSON.stringify({
      amount: data.amount,
      description: data.description,
      category: data.category,
      type: data.transactionType,
      date: new Date().toISOString().split('T')[0],
      source: 'whatsapp'
    }),
    requestContext: {
      authorizer: {
        claims: { sub: userId }
      }
    }
  };

  await lambdaClient.send(new InvokeCommand({
    FunctionName: 'finanzas-transactions',
    Payload: JSON.stringify(payload)
  }));
}

async function sendWhatsAppMessage(to, message) {
  const token = process.env.WHATSAPP_TOKEN;
  const phoneId = process.env.WHATSAPP_PHONE_ID;
  
  if (!token || token === 'TEMP_TOKEN') {
    console.log('WhatsApp token not configured, skipping message');
    return;
  }

  try {
    const response = await fetch(`https://graph.facebook.com/v18.0/${phoneId}/messages`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        messaging_product: 'whatsapp',
        to: to,
        text: { body: message }
      })
    });
    
    if (!response.ok) {
      console.error('WhatsApp API error:', await response.text());
    }
  } catch (error) {
    console.error('Failed to send WhatsApp message:', error);
  }
}

async function createBudget(userId, data) {
  const payload = {
    httpMethod: 'POST',
    body: JSON.stringify({
      category: data.category,
      amount: data.amount,
      period: data.period
    }),
    requestContext: {
      authorizer: {
        claims: { sub: userId }
      }
    }
  };

  await lambdaClient.send(new InvokeCommand({
    FunctionName: 'finanzas-budgets',
    Payload: JSON.stringify(payload)
  }));
}

async function generateReport(userId) {
  const payload = {
    httpMethod: 'GET',
    requestContext: {
      authorizer: {
        claims: { sub: userId }
      }
    }
  };

  const response = await lambdaClient.send(new InvokeCommand({
    FunctionName: 'finanzas-transactions',
    Payload: JSON.stringify(payload)
  }));

  const result = JSON.parse(Buffer.from(response.Payload).toString());
  const body = JSON.parse(result.body);
  
  const transactions = body.transactions || [];
  const totalIncome = transactions.filter(t => t.type === 'income').reduce((sum, t) => sum + t.amount, 0);
  const totalExpense = transactions.filter(t => t.type === 'expense').reduce((sum, t) => sum + t.amount, 0);
  const balance = totalIncome - totalExpense;
  
  console.log(`Report - Income: ${totalIncome}, Expense: ${totalExpense}, Balance: ${balance}`);
}

